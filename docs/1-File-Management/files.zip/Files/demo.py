for s in ['Welcome', 'to', 'PIC', '1!']:
  print(s + ' ', end='')

print()